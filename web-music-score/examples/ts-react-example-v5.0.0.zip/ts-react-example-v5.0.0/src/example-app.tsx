import * as React from "react";
import * as Audio from "@tspro/web-music-score/audio";
import { ClassicalGuitar } from "@tspro/web-music-score/audio-cg";
import * as Score from "@tspro/web-music-score/score";
import * as ScoreUI from "@tspro/web-music-score/react-ui";

type ExampleAppState = { doc: Score.MDocument }

export class ExampleApp extends React.Component<{}, ExampleAppState> {

    state: ExampleAppState;

    constructor(props: {}) {
        super(props);

        Audio.addInstrument(ClassicalGuitar);

        let doc = this.createDocument();

        this.state = { doc }
    }

    render() {
        let { doc } = this.state;

        return (
            <div>
                <h1>TypeScript React Example</h1>
                <p>
                    This is example/project template about how to create and display score using Typescript and React.
                </p>
                <br />
                <ScoreUI.MusicScoreView doc={doc} />
                <br />
                <ScoreUI.PlaybackButtons doc={doc} />
            </div>
        );
    }

    private createDocument(): Score.MDocument {
        return new Score.DocumentBuilder()
            .setHeader("Greensleeves")
            .setScoreConfiguration("guitarTreble")

            .addMeasure()
            .setKeySignature("C Major")
            .setTimeSignature("6/8")
            .setTempo(140)
            .addNote(0, "A3", "8n")

            .addMeasure()
            .addNavigation("startRepeat")
            .addNote(0, "C4", "4n", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "D4", "8n")
            .addNote(0, "E4", "8.")
            .addNote(0, "F4", "16n")
            .addNote(0, "E4", "8n")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "4n")
            .addNote(1, "A2", "8n")
            .addNote(1, "E3", "4n")

            .addMeasure()
            .addNote(0, "D4", "4n", { stem: "up" }).addLabel("chord", "G")
            .addNote(0, "B3", "8n")
            .addNote(0, "G3", "8.").addLabel("chord", "Em")
            .addNote(0, "A3", "16n")
            .addNote(0, "B3", "8n")
            .addNote(1, "G2", "8n", { stem: "down" })
            .addNote(1, "D3", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "4n")

            .addMeasure()
            .addNote(0, "C4", "4n", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "A3", "8n")
            .addNote(0, "A3", "8.").addLabel("chord", "F")
            .addNote(0, "G#3", "16n")
            .addNote(0, "A3", "8n")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "4n")
            .addNote(1, "F2", "8n")
            .addNote(1, "A2", "4n")

            .addMeasure()
            .addNote(0, "B3", "4n", { stem: "up" }).addLabel("chord", "E")
            .addNote(0, "G#3", "8n")
            .addNote(0, "E3", "4n")
            .addNote(0, "A3", "8n")
            .addNote(1, "E2", "8n", { stem: "down" })
            .addNote(1, "B2", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "4n")
            .endRow()

            .addMeasure()
            .addNote(0, "C4", "4n", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "D4", "8n")
            .addNote(0, "E4", "8.")
            .addNote(0, "F4", "16n")
            .addNote(0, "E4", "8n")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "4n")
            .addNote(1, "A2", "8n")
            .addNote(1, "E3", "4n")

            .addMeasure()
            .addNote(0, "D4", "4n", { stem: "up" }).addLabel("chord", "G")
            .addNote(0, "B3", "8n")
            .addNote(0, "G3", "8.").addLabel("chord", "Em")
            .addNote(0, "A3", "16n")
            .addNote(0, "B3", "8n")
            .addNote(1, "G2", "8n", { stem: "down" })
            .addNote(1, "D3", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "4n")

            .addMeasure()
            .addNote(0, "C4", "8.", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "B3", "16n")
            .addNote(0, "A3", "8n")
            .addNote(0, "G#3", "8.").addLabel("chord", "E")
            .addNote(0, "F#3", "16n")
            .addNote(0, "G#3", "8n")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "4n")

            .addMeasure()
            .addNote(0, "A3", "4.", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "A3", "4.")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "8n")
            .addNote(1, "C4", "8n")
            .addNote(1, "A2", "4.")
            .endRow()

            .addMeasure()
            .addChord(0, ["C3", "E3", "G3", "C4", "G4"], "4.", { arpeggio: "up", stem: "up" }).addLabel("chord", "C")
            .addNote(0, "G4", "8.")
            .addNote(0, "F#4", "16n")
            .addNote(0, "E4", "8n")
            .addRest(1, "4.", { hide: true })
            .addNote(1, "C3", "8n", { stem: "down" })
            .addNote(1, "G3", "4n")

            .addMeasure()
            .addNote(0, "D4", "4n", { stem: "up" }).addLabel("chord", "G")
            .addNote(0, "B3", "8n")
            .addNote(0, "G3", "8.").addLabel("chord", "Em")
            .addNote(0, "A3", "16n")
            .addNote(0, "B3", "8n")
            .addNote(1, "G2", "8n", { stem: "down" })
            .addNote(1, "D3", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "4n")

            .addMeasure()
            .addNote(0, "C4", "4n", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "A3", "8n")
            .addNote(0, "A3", "8.").addLabel("chord", "F")
            .addNote(0, "G#3", "16n")
            .addNote(0, "A3", "8n")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "4n")
            .addNote(1, "F2", "8n")
            .addNote(1, "A2", "4n")

            .addMeasure()
            .addNote(0, "B3", "4n", { stem: "up" }).addLabel("chord", "E")
            .addNote(0, "G#3", "8n")
            .addNote(0, "E3", "4.")
            .addNote(1, "E2", "8n", { stem: "down" })
            .addNote(1, "B2", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "8n")
            .addNote(1, "E3", "8n")
            .endRow()

            .addMeasure()
            .addNote(0, "G4", "4.", { stem: "up" }).addLabel("chord", "C")
            .addNote(0, "G4", "8.")
            .addNote(0, "F#4", "16n")
            .addNote(0, "E4", "8n")
            .addNote(1, "C3", "8n", { stem: "down" })
            .addNote(1, "G3", "8n")
            .addNote(1, "C4", "8n")
            .addNote(1, "C3", "8n")
            .addNote(1, "G3", "4n")

            .addMeasure()
            .addNote(0, "D4", "4n", { stem: "up" }).addLabel("chord", "G")
            .addNote(0, "B3", "8n")
            .addNote(0, "G3", "8.").addLabel("chord", "Em")
            .addNote(0, "A3", "16n")
            .addNote(0, "B3", "8n")
            .addNote(1, "G2", "8n", { stem: "down" })
            .addNote(1, "D3", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "4n")

            .addMeasure()
            .addNote(0, "C4", "8.", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "B3", "16n")
            .addNote(0, "A3", "8n")
            .addNote(0, "G#3", "8.").addLabel("chord", "E")
            .addNote(0, "F#3", "16n")
            .addNote(0, "G#3", "8n")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "4n")
            .addNote(1, "E2", "8n")
            .addNote(1, "B2", "4n")

            .addMeasure()
            .addNavigation("ending", 1)
            .addNavigation("endRepeat")
            .addNote(0, "A3", "4.", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "A3", "4n")
            .addNote(0, "A3", "8n")
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "8n")
            .addNote(1, "C4", "8n")
            .addNote(1, "A2", "4.")

            .addMeasure()
            .addNavigation("ending", 2)
            .addNote(0, "A3", "4.", { stem: "up" }).addLabel("chord", "Am")
            .addNote(0, "A3", "4.").addFermata()
            .addNote(1, "A2", "8n", { stem: "down" })
            .addNote(1, "E3", "8n")
            .addNote(1, "C4", "8n")
            .addNote(1, "A2", "4.")

            .getDocument();
    }
}

export default ExampleApp;

# TypeScript React Example/Project Template

To run this example, execute:
- `npm install`
- `npm start`

import * as React from "react";
import { registerClassicalGuitar } from "@tspro/web-music-score/audio-cg";
import * as Score from "@tspro/web-music-score/score";
import * as Theory from "@tspro/web-music-score/theory";
import * as ScoreUI from "@tspro/web-music-score/react-ui";

type ExampleAppState = { doc: Score.MDocument }

export class ExampleApp extends React.Component<{}, ExampleAppState> {

    state: ExampleAppState;

    constructor(props: {}) {
        super(props);

        registerClassicalGuitar();

        let doc = this.createDocument();

        this.state = { doc }
    }

    render() {
        let { doc } = this.state;

        return (
            <div>
                <h1>TypeScript React Example</h1>
                <p>
                    This is example/project template about how to create and display score using Typescript and React.
                </p>
                <br />
                <ScoreUI.MusicScoreView doc={doc} />
                <br />
                <ScoreUI.PlaybackButtons doc={doc} />
            </div>
        );
    }

    private createDocument(): Score.MDocument {
        return new Score.DocumentBuilder()
            .setScoreConfiguration(Score.StaffPreset.GuitarTreble)
            .setHeader("Greensleeves")

            .addMeasure()
            .setKeySignature("C", Theory.ScaleType.Major)
            .setTimeSignature("6/8")
            .setTempo(140)
            .addNote(0, "A3", Theory.NoteLength.Eighth)

            .addMeasure()
            .addNavigation(Score.Navigation.StartRepeat)
            .addNote(0, "C4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "D4", Theory.NoteLength.Eighth)
            .addNote(0, "E4", Theory.NoteLength.Eighth, { dotted: true })
            .addNote(0, "F4", Theory.NoteLength.Sixteenth)
            .addNote(0, "E4", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Quarter)
            .addNote(1, "A2", Theory.NoteLength.Eighth)
            .addNote(1, "E3", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "D4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "G")
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(0, "G3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "Em")
            .addNote(0, "A3", Theory.NoteLength.Sixteenth)
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(1, "G2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "D3", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "C4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(0, "A3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "F")
            .addNote(0, "G#3", Theory.NoteLength.Sixteenth)
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Quarter)
            .addNote(1, "F2", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "B3", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "E")
            .addNote(0, "G#3", Theory.NoteLength.Eighth)
            .addNote(0, "E3", Theory.NoteLength.Quarter)
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(1, "E2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "B2", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Quarter)
            .endRow()

            .addMeasure()
            .addNote(0, "C4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "D4", Theory.NoteLength.Eighth)
            .addNote(0, "E4", Theory.NoteLength.Eighth, { dotted: true })
            .addNote(0, "F4", Theory.NoteLength.Sixteenth)
            .addNote(0, "E4", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Quarter)
            .addNote(1, "A2", Theory.NoteLength.Eighth)
            .addNote(1, "E3", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "D4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "G")
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(0, "G3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "Em")
            .addNote(0, "A3", Theory.NoteLength.Sixteenth)
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(1, "G2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "D3", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "C4", Theory.NoteLength.Eighth, { dotted: true, stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "B3", Theory.NoteLength.Sixteenth)
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(0, "G#3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "E")
            .addNote(0, "F#3", Theory.NoteLength.Sixteenth)
            .addNote(0, "G#3", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "A3", Theory.NoteLength.Quarter, { dotted: true, stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "A3", Theory.NoteLength.Quarter, { dotted: true })
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Eighth)
            .addNote(1, "C4", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Quarter, { dotted: true })
            .endRow()

            .addMeasure()
            .addChord(0, ["C3", "E3", "G3", "C4", "G4"], Theory.NoteLength.Quarter, { dotted: true, arpeggio: Score.Arpeggio.Up, stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "C")
            .addNote(0, "G4", Theory.NoteLength.Eighth, { dotted: true })
            .addNote(0, "F#4", Theory.NoteLength.Sixteenth)
            .addNote(0, "E4", Theory.NoteLength.Eighth)
            .addRest(1, Theory.NoteLength.Quarter, { dotted: true, hide: true })
            .addNote(1, "C3", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "G3", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "D4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "G")
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(0, "G3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "Em")
            .addNote(0, "A3", Theory.NoteLength.Sixteenth)
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(1, "G2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "D3", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "C4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(0, "A3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "F")
            .addNote(0, "G#3", Theory.NoteLength.Sixteenth)
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Quarter)
            .addNote(1, "F2", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "B3", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "E")
            .addNote(0, "G#3", Theory.NoteLength.Eighth)
            .addNote(0, "E3", Theory.NoteLength.Quarter, { dotted: true })
            .addNote(1, "E2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "B2", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Eighth)
            .addNote(1, "E3", Theory.NoteLength.Eighth)
            .endRow()

            .addMeasure()
            .addNote(0, "G4", Theory.NoteLength.Quarter, { dotted: true, stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "C")
            .addNote(0, "G4", Theory.NoteLength.Eighth, { dotted: true })
            .addNote(0, "F#4", Theory.NoteLength.Sixteenth)
            .addNote(0, "E4", Theory.NoteLength.Eighth)
            .addNote(1, "C3", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "G3", Theory.NoteLength.Eighth)
            .addNote(1, "C4", Theory.NoteLength.Eighth)
            .addNote(1, "C3", Theory.NoteLength.Eighth)
            .addNote(1, "G3", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "D4", Theory.NoteLength.Quarter, { stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "G")
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(0, "G3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "Em")
            .addNote(0, "A3", Theory.NoteLength.Sixteenth)
            .addNote(0, "B3", Theory.NoteLength.Eighth)
            .addNote(1, "G2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "D3", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNote(0, "C4", Theory.NoteLength.Eighth, { dotted: true, stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "B3", Theory.NoteLength.Sixteenth)
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(0, "G#3", Theory.NoteLength.Eighth, { dotted: true }).addLabel(Score.Label.Chord, "E")
            .addNote(0, "F#3", Theory.NoteLength.Sixteenth)
            .addNote(0, "G#3", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Quarter)
            .addNote(1, "E2", Theory.NoteLength.Eighth)
            .addNote(1, "B2", Theory.NoteLength.Quarter)

            .addMeasure()
            .addNavigation(Score.Navigation.Ending, 1)
            .addNavigation(Score.Navigation.EndRepeat)
            .addNote(0, "A3", Theory.NoteLength.Quarter, { dotted: true, stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "A3", Theory.NoteLength.Quarter)
            .addNote(0, "A3", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Eighth)
            .addNote(1, "C4", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Quarter, { dotted: true })

            .addMeasure()
            .addNavigation(Score.Navigation.Ending, 2)
            .addNote(0, "A3", Theory.NoteLength.Quarter, { dotted: true, stem: Score.Stem.Up }).addLabel(Score.Label.Chord, "Am")
            .addNote(0, "A3", Theory.NoteLength.Quarter, { dotted: true }).addFermata()
            .addNote(1, "A2", Theory.NoteLength.Eighth, { stem: Score.Stem.Down })
            .addNote(1, "E3", Theory.NoteLength.Eighth)
            .addNote(1, "C4", Theory.NoteLength.Eighth)
            .addNote(1, "A2", Theory.NoteLength.Quarter, { dotted: true })

            .getDocument();
    }
}

export default ExampleApp;
